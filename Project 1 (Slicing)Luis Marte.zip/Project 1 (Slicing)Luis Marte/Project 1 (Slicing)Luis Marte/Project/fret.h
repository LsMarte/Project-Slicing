/*
 * Name: Luis Marte
 * Fret Class Definition
 * Course: CSI218 (Spring 2025)
 * Date: 04/14/2025
 * Description: Fret class definition declaring data members and
 *				member functions.  Represents a rectangular fret
 *				in which each position holds a value of a particular
 *				type.  A 2-dimension position (x and y) is specified
 *				by a pair<int, int>.
 */

#ifndef FRET_H
#define FRET_H

#include <iostream>
#include <utility>
using namespace std;
// Class to represent a rectangular area of values that can be
// accessed by an x an y index.
template<class T>
class Fret
{
public:
	// Constructor to set up size and with initial value.
	Fret(int xSixe, int ySize, T initialValue);

	//copy constructor
	Fret(const Fret<T>& otherFret);

	//Assigment operator
	Fret<T>& operator=(const Fret<T>& otherFret);

	//Destructor
	~Fret();

	// Return size in x dimension.
	int getXSize() const;
	
	// Return size in y dimension.
	int getYSize() const;

	// Get copy of value at particular position specified
	// by pair passed (first value is x, second value is y).
	T operator[](const std::pair<int, int>& pos) const;
	// Precondition: x and y position passed is zero-based
	// and must be within the size.

	// Get value at particular position specified by pair
	// passed (first value is x, second value is y) via a
	// reference (i.e., can assign return value).
	T& operator[](const std::pair<int, int>& pos);
	// Precondition: x and y position passed is zero-based
	// and must be within the size.
	
private:
	// Size of 2D array storing values.
	 int X_SIZE; //width of array
	 int Y_SIZE; //height of array

	// Values of particular type to be stored.
	 //pointer to a dinamically allocated 2D
	T** pattern;
};

//Overload the output stream operator for Fret
template<class T>
ostream& operator<<(ostream& os, const Fret<T>& fret);

#endif