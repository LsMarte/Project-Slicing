/*
 * Name: Luis Marte
 * Project 1: Slicing
 * Course: CSI218 (Spring 2025)
 * Date: 04/14/2025
 * Description: Print a 3D volume made up from shapes, namely,
 *				spheres and cubes at variable positions and sizes.
 *				Since shapes may overlap each other and the edges
 *				of the volume, complex volumes (objects) can be
 *				created. The volume is stored in 2D slices, which
 *				can be duplicated and also be interspersed with
 *				empty slices. When the volume is complete, supports
 *				may be added before printing.
 */

#include <iostream>
#include <string>
#include <vector>
#include <utility>
#include <cctype>
#include "fret.cpp"
#include <cmath> // for pow and abs
using namespace std;

// Constants for what fills volume locations.
const char EMPTY = '.';    // empty
const char FILAMENT = '*'; // filled with filament
const char SUPPORT = '#';  // filled with support material

// Declarations for functions that help control 3D printing.

// Allow user to enter a position (force re-entry if
// out of range).
int enterValidatePos(const string& desc, int max);

// Draw sphere with center and radius passed.
// Note: Parts of sphere outside volume ignored.
void drawSphere(vector<Fret<char>>& volume, int centerX, int centerY, int centerZ, int radius);

// Draw cube with center and half-edge length
// (radius) passed.
// Note: Parts of cube outside volume ignored.
void drawCube(vector<Fret<char>>& volume, int centerX, int centerY, int centerZ, int halfEdgeLength);

// Add supports for empty regions below filament
// or support material.
void addSupports(vector<Fret<char>>& volume);

// Count amount of material being used.
int countMaterial(const vector<Fret<char>>& volume);

int main()
{
	// Allow user to enter size of 3D print: x (left->right),
	// y (back->front), z (bottom->top), all in terms of number
	// of characters.  Enforces maximum dimensions.
	const int DIM_MAX = 30;
	int volumeX, volumeY, volumeZ;
	do
	{
		cout << "Size of volume (x y z): ";

		cin >> volumeX >> volumeY >> volumeZ;

		if (volumeX > 0 && volumeX <= DIM_MAX &&
				volumeY > 0 && volumeY <= DIM_MAX &&
				volumeZ > 0 && volumeZ <= DIM_MAX)
			break;

		cerr << "\nVolume cannot be larger than "
			 << DIM_MAX << "x" << DIM_MAX << "x" << DIM_MAX << endl;
	} while (true);

	// Create slices representing 3D volume.
	vector<Fret<char>> slices(volumeZ, Fret<char>(volumeX, volumeY, EMPTY));
	
	// Allow user to modify volume until ready to print.
	// Note: User enters 1-based indices but code uses
	// zero-based indices.
	while (true)
	{
		// Display size of volume and amount of material used.
		cout << "\nVolume: "
			 << slices[0].getXSize() << "x"
			 << slices[0].getYSize() << "x"
			 << slices.size();
		cout << " (material used: "
			 << countMaterial(slices) << " units)" << endl;

		// Allow user to choose volume operation.
		cout << "Operations:" << endl;
		cout << "Fill s)phere" << endl;
		cout << "Fill c)ube" << endl;
		cout << "Insert e)mpty slice" << endl;
		cout << "D)uplicate slice" << endl;
		cout << "P)rint" << endl;
		cout << "> ";
		char op;
		cin >> op;
		op = tolower(op);

		// Done creating volume, print?
		if (op == 'p')
			break;

		// Used for user input under various operations.
		int posX;
		int posY;
		int posZ;
		int radius;

		// Process requested volume operation.
		switch (op)
		{
		case 's':
			// Position doesn't have to be inside volume.
			cout << "Center of sphere (x y z): ";
			cin >> posX >> posY >> posZ;
			cout << "Radius of sphere: ";
			cin >> radius;
			drawSphere(slices, posX - 1, posY - 1, posZ - 1, radius);
			break;

		case 'c':
			// Position doesn't have to be inside volume.
			cout << "Center of cube (x y z): ";
			cin >> posX >> posY >> posZ;
			cout << "Half-edge length of cube: ";
			cin >> radius;
			drawCube(slices, posX - 1, posY - 1, posZ - 1, radius);
			break;

		case 'e':
		{  // Block for local variables.
			posZ = enterValidatePos("Place slice below [z]", slices.size() + 1);
			// COMPLETE OPERATION.
			// this insert a new empty slice for Fret at the specified position
			slices.insert(slices.begin() + (posZ - 1), Fret<char>(volumeX, volumeY, EMPTY));
			break;
		}

		case 'd':
		{  // Block for local variables.
			posZ = enterValidatePos("Slice to duplicate [z]", slices.size());
			Fret<char> duplicate = slices[posZ - 1];
			posZ = enterValidatePos("Replace which slice [z]", slices.size());
			slices[posZ - 1] = duplicate;
			break;
		}

		default:
			cerr << "Invalid operation: " << op << endl;
			break;
		}
	}

	// Determine if user wants to add support material
	// underneath any filament (also under any supporting
	// material added).
	cout << "Add full supports if needed (y/n)? ";
	char supportsAns;
	cin >> supportsAns;
	if (tolower(supportsAns) == 'y')
		addSupports(slices);

	// Output slices from lowest to highest.
	cout << "\nPrinting volume..." << endl;

	for (int z = 0; z < slices.size(); z++)
	{
	  cout << "Slice #" << (z + 1) << endl;
	  cout << slices[z] << endl;
	}

	return 0;
}

// Definitions for functions that help control 3D printing.

// Allow user to enter a position (force re-entry if
// out of range).
int enterValidatePos(const string& desc, int max)
{
	int pos;

	do
	{
		cout << desc << " (1 to " << max << "): ";
		cin >> pos;
		if (pos < 1 || pos > max)
			cerr << "Position out of range: " << pos << endl;
		else
			break;
	} while (true);

	return pos;
}

// Draw sphere with center and radius passed.
// Note: Parts of sphere outside volume ignored.
void drawSphere(vector<Fret<char>>& volume, int centerX, int centerY, int centerZ, int radius)
{
	// FILL IN FUNCTION.
	// this Iterate the volume  to determine which point fall.
	for (int z = 0; z < volume.size(); z++) 
	{
		for (int y = 0; y < volume[0].getYSize(); y++) 
		{
			for (int x = 0; x < volume[0].getXSize(); x++) 
			{
				// This check if the point x, y, z is within the radius sphere.
				if (pow(x - centerX, 2) + pow(y - centerY, 2) + pow(z - centerZ, 2) <= pow(radius, 2))
				{
					//Mark the point as Filament
					volume[z][{x, y}] = FILAMENT;
				}
			}
		}
	}
}


// Draw cube with center and half-edge length
// (radius) passed.
// Note: Parts of cube outside volume ignored.
void drawCube(vector<Fret<char>>& volume, int centerX, int centerY, int centerZ, int halfEdgeLength)
{
	// FILL IN FUNCTION.
	// Iterate through the volume to determine which points fall within the cube.
	for (int z = 0; z < volume.size(); ++z)
	{
		for (int z = 0; z < volume.size(); z++)
		{
			for (int y = 0; y < volume[0].getYSize(); y++)
			{
				for (int x = 0; x < volume[0].getXSize(); x++)
				{
					// This check if the point x, y, z is within the bounds cube.
					if (abs(x - centerX) <= halfEdgeLength &&
						abs(y - centerY) <= halfEdgeLength &&
						abs(z - centerZ) <= halfEdgeLength)
					{
						//Mark point as Filament
						volume[z][{x, y}] = FILAMENT;
					}
				}
			}
		}
	}
}

	// Add supports for empty regions below filament
// or support material.
void addSupports(vector<Fret<char>>& volume)
{
	// FILL IN FUNCTION.
	// Iterate through the volume starting from second layer
	for (int z = 1; z < volume.size(); z++) 
	{
		for (int y = 0; y < volume[0].getYSize(); y++) 
		{
			for (int x = 0; x < volume[0].getXSize(); x++) 
			{//check is the position is empty
				if (volume[z][{x, y}] == EMPTY) 
				{
					//If the position directly Filament or support.
					if (volume[z - 1][{x, y}] == FILAMENT ||
						volume[z - 1][{x, y}] == SUPPORT) 
					{
						//Mark position as support
						volume[z][{x, y}] = SUPPORT; 
					}
				}
			}
		}
	}
}

// Count amount of material being used.
int countMaterial(const vector<Fret<char>>& volume)
{
	// FILL IN FUNCTION.
	int count = 0;
	// Iterate through the volume to count the filament and support
	for (int z = 0; z < volume.size(); z++)
	{
		for (int y = 0; y < volume[0].getYSize(); y++)
		{
			for (int x = 0; x < volume[0].getXSize(); x++)
			{
				//Increment or support found each filament.
				if (volume[z][{x, y}] == FILAMENT ||
					volume[z][{x, y}] == SUPPORT)
				{
					count++;
				}
			}
		}
	}
	return count; // this retrn the count of material used it.
}

