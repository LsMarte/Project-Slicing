/*
 * Name: Luis Marte
 * Fret Class Member Function Definitions
 * Course: CSI218 (Spring 2025)
 * Date: 04/14/2025
 * Description: Fret member function definitions.
 */

#ifndef FRET_CPP
#define FRET_CPP

#include <iostream>
#include <utility>
#include "fret.h"

using namespace std;
// Definitions for template class member functions.

// Constructor to set up size and with initial value.
// MODIFY CONSTRUCTOR.
template<class T>
Fret<T>::Fret(int xSize, int ySize, T initialValue)
	: X_SIZE(xSize), Y_SIZE(ySize)
{
	cout << "Constructor called" << endl;
	//Allocate array of pointers
     pattern = new T* [X_SIZE];
	 for (int i = 0; i < X_SIZE; i++)
	 {
		 //Allocate row
		 pattern[i] = new T[ySize];

		 // initialize each element in the row
		 for (int j = 0; j < ySize; j++)
		 {
			 pattern[i][j] = initialValue;
		 }
	 }
} 
//copy constructor
template<class T>
Fret<T>::Fret(const Fret& otherFret)
	: X_SIZE(otherFret.X_SIZE), Y_SIZE(otherFret.Y_SIZE)
{
	cout << "Copy constructor called" << endl;
	//Allocate array of pointers for copy of other fret.
	pattern = new T*[X_SIZE];
	for (int i = 0; i < X_SIZE; i++)
	{
		//Allocate row
		pattern[i] = new T[Y_SIZE];

		//Copy values from the other fret
		for (int j = 0; j < Y_SIZE; j++)
		{
		  pattern[i][j] = otherFret.pattern[i][j];
		}

	}
}

//Assigment operator
template<class T>
Fret<T>& Fret<T>::operator=(const Fret<T>& otherFret)
{
	// Avoid self assignment
	if (this != &otherFret)
	{
		//Allocate new memory and copy the values
		X_SIZE = otherFret.X_SIZE;
		Y_SIZE = otherFret.Y_SIZE;

		//deallocate existing memory
		for (int i = 0; i < X_SIZE; i++)
		{
			delete[] pattern[i];
		}
		delete[] pattern;

		//allocate new memory
		pattern = new T*[X_SIZE];
		for (int i = 0; i < X_SIZE; i++)
		{
			pattern[i] = new T[Y_SIZE];
			// copy values
			for (int j = 0; j < Y_SIZE; j++)
			{
				pattern[i][j] = otherFret.pattern[i][j];
			}
		}
	}
	return *this; //return the object current
}

// Destructure 
template<class T>
Fret<T>::~Fret()
{
	cout << "Destructor called" << endl;
	// Deallocate each row
	for (int i = 0; i < X_SIZE; i++)
	{
		//delete each row
		delete[] pattern[i]; 
	}
	//delete the array of pointers
	delete[] pattern; // Deallocate dynamic array
	pattern = NULL; //prevent dangling pointer
}

// Return size in x dimension.
template<class T>
int Fret<T>::getXSize() const
{
	return xSize;
}

// Return size in y dimension.
template<class T>
int Fret<T>::getYSize() const
{
	return ySize;
}

// Get copy of value at particular position specified
// by pair passed (first value is x, second value is y).
// Precondition: x and y position passed is zero-based
// and must be within the size.
template<class T>
T Fret<T>::operator [](const std::pair<int, int>& pos) const
{
	cout << "Const [] operator called" << endl;
	// Return value at specified position.
	return pattern[pos.first][pos.second];
}

// Get value at particular position specified by pair
// passed (first value is x, second value is y) via a
// reference (i.e., can assign return value).
// Precondition: x and y position passed is zero-based
// and must be within the size.
template<class T>
T& Fret<T>::operator [](const std::pair<int, int>& pos)
{
	cout <<"Non-const [] operator called" << endl;
	// Place value at specified position.
	return pattern[pos.first][pos.second];
}

// overload the output operator for fret
template<class T>
ostream& operator<<(ostream& ost, const Fret<T>& fret)
{
	//this is the output of the Fret object
	os << "X Size: " << fret.getXSize() << ", Y Size: " 
		<< fret.getYSize() << endl;
	// Iterate each row of the Fret
	for (int y = 0; y < fret.getYSize(); ++y) {
		for (int x = 0; x < fret.getXSize(); ++x) {
			os << fret[{x, y}]; /// Output the value at the (x, y) position in the Fret.
		}
		os << endl; //After printing all columns in the current row.
	}
	return os;
}


#endif

	